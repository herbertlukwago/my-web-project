function validateCredentials(email,password){
    const validEmail = "lukwago herbert@gmail.com"
    const validPassword = "2200704478@2024"


    if (email === validEmail && password === validPassword){
        console.log('user email is {email}, login successfully!');
    } else {
        console.log("incorrect user credentials");
    }
    }
    validateCredentials('lukwago herbert@gmail.com','2200704478@2024')

